package com.cg.mobilebilling.controllers;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
@Controller
public class PostPaidAccountController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping("/closeCustomerPostPaidAccountSuccessful")
	public ModelAndView closeCustomerPostPaidAccount(@RequestParam int customerID,@RequestParam long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
			billingServices.closeCustomerPostPaidAccount(customerID, mobileNo);
			return new ModelAndView("closeCustomerPostPaidAccountSuccessfulPage","mobileNo",mobileNo);
	}
	@RequestMapping("/postpaidAccount")
	public ModelAndView openPostpaidMobileAccount(@RequestParam int customerID,@RequestParam int planID) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		long mobileNumber = billingServices.openPostpaidMobileAccount(customerID, planID);
			return new ModelAndView("PostpaidAccountSuccessPage","mobileNumber",mobileNumber);
	}
	@RequestMapping("/postpaidAccountDetails")
	public ModelAndView getpostpaidAccountDetails(@RequestParam int customerID,@RequestParam long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		PostpaidAccount postpaid = billingServices.getPostPaidAccountDetails(customerID, mobileNo);
			return new ModelAndView("postpaidAccountDetailsPage","postpaid",postpaid);
	}
	@RequestMapping("/customerAllPostpaidAccountDetails")
	public ModelAndView getCustomerAllPostpaidAccountDetails(@RequestParam int customerID) throws CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException {
		List<PostpaidAccount> postpaids = billingServices.getCustomerAllPostpaidAccountsDetails(customerID);
			return new ModelAndView("customerAllPostpaidAccountDetailsPage","postpaids",postpaids);
	}	
}