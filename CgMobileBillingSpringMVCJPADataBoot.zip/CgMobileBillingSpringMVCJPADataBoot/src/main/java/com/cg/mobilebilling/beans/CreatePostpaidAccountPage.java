package com.cg.mobilebilling.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CreatePostpaidAccountPage {
	@FindBy(how=How.NAME,name="customerID")
	private WebElement customerID;
	@FindBy(how=How.NAME,name="planID")
	private WebElement planID;
	@FindBy(how=How.XPATH,xpath="/html/body/section/form/table/tbody/tr[4]/td[2]/input")
	private WebElement button;
	@FindBy(how=How.XPATH,xpath="/html/body/pre")
	private WebElement errorMessage;
	
	public CreatePostpaidAccountPage() {}
	
	public String getCustomerID() {
		return customerID.getAttribute("value");
	}
	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);;
	}
	public String getPlanID() {
		return planID.getAttribute("value");
	}
	public void setPlanID(String planID) {
		this.planID.sendKeys(planID);;
	}
	
	public String getErrorMessage() {
		return errorMessage.getText();
	}

	public void clickSubmit() {
		button.submit();
	}
}