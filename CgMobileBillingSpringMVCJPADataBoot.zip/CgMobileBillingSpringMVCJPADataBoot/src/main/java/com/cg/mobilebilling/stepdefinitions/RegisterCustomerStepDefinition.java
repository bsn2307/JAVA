package com.cg.mobilebilling.stepdefinitions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.mobilebilling.beans.RegisterCustomerPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class RegisterCustomerStepDefinition {
	private WebDriver driver;
	private RegisterCustomerPage registerCustomerPage;
	@Given("^User is on Mobile Billing HomePage$")
	public void user_is_on_Mobile_Billing_HomePage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		   driver=new ChromeDriver();
		   driver.get("http://localhost:1126");
		   registerCustomerPage=PageFactory.initElements(driver, RegisterCustomerPage.class);
	}
	
	@When("^Clicked on 'Customer Registration'$")
	public void clicked_on_Customer_Registration() throws Throwable {
		By customerRegistration=By.name("customerRegistration");
	    WebElement customerRegistrationTxt=driver.findElement(customerRegistration);
	    customerRegistrationTxt.click();
	}
	
	@When("^enters valid details$")
	public void enters_valid_details() throws Throwable {
	    registerCustomerPage.setFirstName("Suprathik");
	    registerCustomerPage.setLastName("Barigala");
	    registerCustomerPage.setEmailID("sb@gmail.com");
	    registerCustomerPage.setDateOfBirth("11/21/2018");
	    registerCustomerPage.setCity("Hyderabad");
	    registerCustomerPage.setState("Telangana");
	    registerCustomerPage.setPinCode("500062");
	    registerCustomerPage.clickSubmit();
	}

	@Then("^Displays 'Customer Registration Successful page'$")
	public void displays_Customer_Registration_Successful_page() throws Throwable {
		String actualTitle=driver.getTitle();
	    String expectedTitle="Customer Registration Successful";
	    Assert.assertEquals(expectedTitle,actualTitle);
	    driver.close();
	}

	@When("^enters invalid details$")
	public void enters_invalid_details() throws Throwable {
	    registerCustomerPage.setLastName("Barigala");
	    registerCustomerPage.setEmailID("sb@gmail.com");
	    registerCustomerPage.setDateOfBirth("11/21/2018");
	    registerCustomerPage.setCity("Hyderabad");
	    registerCustomerPage.setState("Telangana");
	    registerCustomerPage.setPinCode("500062");
	    registerCustomerPage.clickSubmit();
	}

	@Then("^Displays 'Error page'$")
	public void displays_Error_page() throws Throwable {
	    String actualErrorMessage=driver.switchTo().alert().getText();
	    String expectedErrorMessage="First Name must be characters and should not be empty";
	    Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	    driver.close();
	}
}