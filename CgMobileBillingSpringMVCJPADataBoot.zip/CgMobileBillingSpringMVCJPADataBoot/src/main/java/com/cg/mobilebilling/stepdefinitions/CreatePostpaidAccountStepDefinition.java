package com.cg.mobilebilling.stepdefinitions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.mobilebilling.beans.CreatePostpaidAccountPage;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreatePostpaidAccountStepDefinition {
	private WebDriver driver;
	private CreatePostpaidAccountPage createPostpaidAccountPage;
	@Given("^User is on Mobile Billing HomePage for creating postpaid account$")
	public void user_is_on_Mobile_Billing_HomePage_for_creating_postpaid_account() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		   driver=new ChromeDriver();
		   driver.get("http://localhost:1126");
		   createPostpaidAccountPage=PageFactory.initElements(driver, CreatePostpaidAccountPage.class);
	}

	@When("^Clicked on 'Create Postpaid Account'$")
	public void clicked_on_Create_Postpaid_Account() throws Throwable {
		By openPostpaidAccount=By.name("openPostpaidAccount");
	    WebElement openPostpaidAccountTxt=driver.findElement(openPostpaidAccount);
	    openPostpaidAccountTxt.click();
	}

	@When("^enters valid details in create postpaid account$")
	public void enters_valid_details_in_create_postpaid_account() throws Throwable {
	    createPostpaidAccountPage.setCustomerID("116");
	    createPostpaidAccountPage.setPlanID("2");
	    createPostpaidAccountPage.clickSubmit();
	}

	@Then("^Displays 'Postpaid Account Registration Successful page'$")
	public void displays_Postpaid_Account_Registration_Successful_page() throws Throwable {
		String actualTitle=driver.getTitle();
	    String expectedTitle="Postpaid Account Registered Successful";
	    Assert.assertEquals(expectedTitle,actualTitle);
	    driver.close();
	}

	@When("^does not entered any details$")
	public void does_not_entered_any_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Displays 'Alert box'$")
	public void displays_Alert_box() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^entered wrong 'Customer ID' in create postpaid account$")
	public void entered_wrong_Customer_ID_in_create_postpaid_account() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
