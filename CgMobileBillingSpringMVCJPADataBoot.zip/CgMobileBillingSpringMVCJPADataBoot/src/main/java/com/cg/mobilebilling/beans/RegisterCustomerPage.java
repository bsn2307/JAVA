package com.cg.mobilebilling.beans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
public class RegisterCustomerPage {
	@FindBy(how=How.NAME,name="firstName")
	private WebElement firstName;
	@FindBy(how=How.NAME,name="lastName")
	private WebElement lastName;
	@FindBy(how=How.NAME,name="emailID")
	private WebElement emailID;
	@FindBy(how=How.NAME,name="dateOfBirth")
	private WebElement dateOfBirth;
	@FindBy(how=How.NAME,name="billingAddress.city")
	private WebElement city;
	@FindBy(how=How.NAME,name="billingAddress.state")
	private WebElement state;
	@FindBy(how=How.NAME,name="billingAddress.pinCode")
	private WebElement pinCode;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"registerCustomerFrm\"]/table/tbody/tr[8]/td/input")
	private WebElement button;
	
	public RegisterCustomerPage() {}
	
	public String getFirstName() {
		return firstName.getAttribute("value");
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public String getLastName() {
		return lastName.getAttribute("value");
	}
	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}
	public String getEmailID() {
		return emailID.getAttribute("value");
	}
	public void setEmailID(String emailID) {
		this.emailID.sendKeys(emailID);
	}
	public String getDateOfBirth() {
		return dateOfBirth.getAttribute("value");
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth.sendKeys(dateOfBirth);
	}
	public String getCity() {
		return city.getAttribute("value");
	}
	public void setCity(String city) {
		this.city.sendKeys(city);
	}
	public String getState() {
		return state.getAttribute("value");
	}
	public void setState(String state) {
		this.state.sendKeys(state);
	}
	public String getPinCode() {
		return pinCode.getAttribute("value");
	}
	public void setPinCode(String pinCode) {
		this.pinCode.clear();
		this.pinCode.sendKeys(pinCode);
	}
	public void clickSubmit() {
		button.submit();
	}
	
}
