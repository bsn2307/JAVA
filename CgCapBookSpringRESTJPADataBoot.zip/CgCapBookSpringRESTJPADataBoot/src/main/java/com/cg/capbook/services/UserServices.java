package com.cg.capbook.services;

import com.cg.capbook.beans.Person;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;

public interface UserServices {
	Person signUp(Person user);
	Person SignIn(String emailId,String password) throws UserDetailsNotFoundException;
}
