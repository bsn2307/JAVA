package com.cg.capbook.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition {

	@Given("^User is on loginPage to login to CapBook account$")
	public void user_is_on_loginPage_to_login_to_CapBook_account() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^Clicked on 'Login'$")
	public void clicked_on_Login() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^enters valid details in Login$")
	public void enters_valid_details_in_Login() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^Displays 'Home Page'$")
	public void displays_Home_Page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Given("^User is on loginPage for creating CapBook account$")
	public void user_is_on_loginPage_for_creating_CapBook_account() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^does not entered any details$")
	public void does_not_entered_any_details() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^Displays 'Alert box'$")
	public void displays_Alert_box() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^entered invalid 'Email ID'$")
	public void entered_invalid_Email_ID() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^entered invalid 'Password'$")
	public void entered_invalid_Password() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}


}
