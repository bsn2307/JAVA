package com.cg.capbook.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class IndexStepDefinition {

	@Given("^User is on Index Page of CapBook$")
	public void user_is_on_Index_Page_of_CapBook() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^Clicked on 'Sign Up'$")
	public void clicked_on_Sign_Up() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^Displays 'Sign Up Page'$")
	public void displays_Sign_Up_Page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^Clicked on 'Login'$")
	public void clicked_on_Login() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^Displays 'Login Page'$")
	public void displays_Login_Page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}


}
