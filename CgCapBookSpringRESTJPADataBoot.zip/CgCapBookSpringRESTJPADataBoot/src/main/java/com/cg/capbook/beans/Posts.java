package com.cg.capbook.beans;

public class Posts {

}
