package com.cg.capbook.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Person;
import com.cg.capbook.dao.UserDAO;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
@Component(value="userServices")
public class UserServicesImpl implements UserServices{
	@Autowired
	private UserDAO userDAO;

	@Override
	public Person signUp(Person user) {
	    user=userDAO.save(user);
		return user;
	}

	@Override
	public Person SignIn(String emailId, String password) throws UserDetailsNotFoundException {
		Person user=userDAO.findById(emailId).orElseThrow(()->
		new UserDetailsNotFoundException("User Details Not Found With emailId="+emailId));
		return user;
	}


}
