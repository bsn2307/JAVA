package com.cg.capbook.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SignUpStepDefinition {
	@Given("^User is on signUpPage for creating CapBook account$")
	public void user_is_on_signUpPage_for_creating_CapBook_account() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^enters valid details in Sign Up$")
	public void enters_valid_details_in_Sign_Up() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^Displays 'Sign Up Successful Page'$")
	public void displays_Sign_Up_Successful_Page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^does not entered any details$")
	public void does_not_entered_any_details() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^Displays 'Alert box'$")
	public void displays_Alert_box() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^entered invalid 'Email ID'$")
	public void entered_invalid_Email_ID() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^entered invalid 'First Name'$")
	public void entered_invalid_First_Name() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^entered invalid 'Last Name'$")
	public void entered_invalid_Last_Name() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^entered invalid 'Phone No'$")
	public void entered_invalid_Phone_No() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^entered invalid 'Password'$")
	public void entered_invalid_Password() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}


}
