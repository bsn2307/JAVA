package com.cg.project.stepdefinitions;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.github.beans.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class GitHubLoginStepDefinition {
	private WebDriver driver;
	private LoginPage loginPage;
	@Given("^User is on GitHub HomePage$")
	public void user_is_on_GitHub_HomePage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		   driver=new ChromeDriver();
		   driver.get("https://github.com/login");
		   loginPage=PageFactory.initElements(driver, LoginPage.class);
	}

	@When("^User enters valid Username and password$")
	public void user_enters_valid_Username_and_password() throws Throwable {
		loginPage.setUsername("bsn2307");
		loginPage.setPassword("Barigala@12");
		loginPage.clickSignIn();
	}

	@Then("^Displays user account Home Page$")
	public void displays_user_account_Home_Page() throws Throwable {
		String actualTitle=driver.getTitle();
	    String expectedTitle="GitHub";
	    Assert.assertEquals(expectedTitle,actualTitle);
	    driver.close();
	}
	

	@When("^User enters valid Username and invalid password$")
	public void user_enters_valid_Username_and_invalid_password() throws Throwable {
		loginPage.setUsername("bsn2307");
		loginPage.setPassword("Barigala@123");
		loginPage.clickSignIn();
	}

	@Then("^Displays error Home Page$")
	public void displays_error_Home_Page() throws Throwable {
		String actualTitle=loginPage.getActualErrorMessage();
	    String expectedTitle="Incorrect username or password.";
	    Assert.assertEquals(expectedTitle,actualTitle);
	    driver.close();
	}

	@When("^User enters invalid Username and valid password$")
	public void user_enters_invalid_Username_and_valid_password() throws Throwable {
		loginPage.setUsername("bsn23074");
		loginPage.setPassword("Barigala@12");
		loginPage.clickSignIn();
	}
}