package com.cg.banking.controllers;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;
@Controller
public class OpenAccountController {
	@Autowired
	private BankingServices bankingServices ;
	@RequestMapping("/openAccountCustomer")
	public ModelAndView registerAssociateAction(@Valid @ModelAttribute Account account,BindingResult result) {
		if(result.hasErrors())
			return new ModelAndView("openAccountPage");
		account=bankingServices.openAccount(account);
		return new ModelAndView("displayNewAccountDetailsPage", "account", account);
	}
}