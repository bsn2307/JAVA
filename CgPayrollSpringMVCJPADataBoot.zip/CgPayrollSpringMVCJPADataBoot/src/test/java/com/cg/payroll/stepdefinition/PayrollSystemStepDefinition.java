package com.cg.payroll.stepdefinition;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.payroll.beans.WebElements;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class PayrollSystemStepDefinition {
	private WebDriver driver;
	private WebElements webElements;
	@Given("^User is on Home page$")
	public void user_is_on_Home_page() throws Throwable {
		System.setProperty("Webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:1690");
		webElements=PageFactory.initElements(driver, WebElements.class);
	}
	@When("^User clicks on register$")
	public void user_clicks_on_register() throws Throwable {
		webElements.clickRegister();
	}
	@Then("^Display register page$")
	public void display_register_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
	@Then("^User enters the valid details$")
	public void user_enters_the_valid_details() throws Throwable {
		webElements.setFirstName("shravan");
		webElements.setLastName("marutha");
		webElements.setDepartment("production");
		webElements.setDesignation("A.con");
		webElements.setPancard("112SD132");
		webElements.setEmailId("shravan@gamil.com");
		webElements.setYearlyInvestmentUnder80c("1000");
		webElements.setAccountNumber("213123");
		webElements.setBankName("HDFC");
		webElements.setIfscCode("SDF231");
		webElements.setBasicSalary("10000");
		webElements.setEpf("1234");
		webElements.setCompanyPf("1234");
		webElements.clickSignIn();
	}
	@Then("^Display registration successful page$")
	public void display_registration_successful_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration Success";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
	@Given("^User is on check  associate details page$")
	public void user_is_on_check_associate_details_page() throws Throwable {
		System.setProperty("Webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:1690/getAssociateDetails");
		webElements=PageFactory.initElements(driver, WebElements.class);
	}
	@When("^User enters valid associate Id$")
	public void user_enters_valid_associate_Id() throws Throwable {
		webElements.setAssociateId("1");
		webElements.clickAssociateDetails();
	}
	@Then("^Display associate details$")
	public void display_associate_details() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Get Associate Details";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
	@When("^User clicks on check all assoicate details$")
	public void user_clicks_on_check_all_assoicate_details() throws Throwable {
		webElements.clickAllAssociateDetails();
	}
	@Then("^Display all associate details page$")
	public void display_all_associate_details_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="All Associate Details";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
}