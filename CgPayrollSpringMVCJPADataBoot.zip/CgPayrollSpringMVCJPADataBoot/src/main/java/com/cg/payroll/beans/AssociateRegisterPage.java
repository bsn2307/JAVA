package com.cg.payroll.beans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
public class AssociateRegisterPage {
	@FindBy(how=How.NAME,name="firstName")
	private WebElement firstName;
	@FindBy(how=How.NAME,name="lastName")
	private WebElement lastName;
	@FindBy(how=How.NAME,name="department")
	private WebElement department;
	@FindBy(how=How.NAME,name="designation")
	private WebElement designation;
	@FindBy(how=How.NAME,name="pancard")
	private WebElement panCard;
	@FindBy(how=How.NAME,name="emailId")
	private WebElement emailId;
	@FindBy(how=How.NAME,name="yearlyInvestmentUnder80c")
	private WebElement yearlyInvestmentUnder80c;
	@FindBy(how=How.NAME,name="bankDetails.accountNumber")
	private WebElement accountNo;
	@FindBy(how=How.NAME,name="bankDetails.bankName")
	private WebElement bankName;
	@FindBy(how=How.NAME,name="bankDetails.ifscCode")
	private WebElement bankCode;
	@FindBy(how=How.NAME,name="salary.basicSalary")
	private WebElement basicSalary;
	@FindBy(how=How.NAME,name="salary.epf")
	private WebElement epf;
	@FindBy(how=How.NAME,name="salary.companyPf")
	private WebElement companyPf;
	@FindBy(how=How.XPATH,xpath="/html/body/div/table/tbody/tr[14]/td/input")
	private WebElement button;
	
	public AssociateRegisterPage() {}

	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getDepartment() {
		return department.getAttribute("value");
	}

	public void setDepartment(String department) {
		this.department.sendKeys(department);
	}

	public String getDesignation() {
		return designation.getAttribute("value");
	}

	public void setDesignation(String designation) {
		this.designation.sendKeys(designation);
	}

	public String getPanCard() {
		return panCard.getAttribute("value");
	}

	public void setPanCard(String panCard) {
		this.panCard.sendKeys(panCard);
	}

	public String getEmailId() {
		return emailId.getAttribute("value");
	}

	public void setEmailId(String emailId) {
		this.emailId.sendKeys(emailId);
	}

	public String getYearlyInvestmentUnder80c() {
		return yearlyInvestmentUnder80c.getAttribute("value");
	}

	public void setYearlyInvestmentUnder80c(String yearlyInvestmentUnder80c) {
		this.yearlyInvestmentUnder80c.sendKeys(yearlyInvestmentUnder80c);
	}

	public String getAccountNo() {
		return accountNo.getAttribute("value");
	}

	public void setAccountNo(String accountNo) {
		this.accountNo.sendKeys(accountNo);
	}

	public String getBankName() {
		return bankName.getAttribute("value");
	}

	public void setBankName(String bankName) {
		this.bankName.sendKeys(bankName);
	}

	public String getBankCode() {
		return bankCode.getAttribute("value");
	}

	public void setBankCode(String bankCode) {
		this.bankCode.sendKeys(bankCode);
	}

	public String getBasicSalary() {
		return basicSalary.getAttribute("value");
	}

	public void setBasicSalary(String basicSalary) {
		this.basicSalary.sendKeys(basicSalary);
	}

	public String getEpf() {
		return epf.getAttribute("value");
	}

	public void setEpf(String epf) {
		this.epf.sendKeys(epf);
	}

	public String getCompanyPf() {
		return companyPf.getAttribute("value");
	}

	public void setCompanyPf(String companyPf) {
		this.companyPf.sendKeys(companyPf);
	}
	
	public void clickRegister() {
		button.click();
	}	
}