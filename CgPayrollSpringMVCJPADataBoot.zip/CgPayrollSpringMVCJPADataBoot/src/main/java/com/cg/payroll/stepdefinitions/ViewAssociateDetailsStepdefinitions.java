package com.cg.payroll.stepdefinitions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.payroll.beans.ViewAssociateDetailsPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class ViewAssociateDetailsStepdefinitions {
	private WebDriver driver;
	private ViewAssociateDetailsPage viewAssociateDetailsPage;
	@Given("^Associate is on the Payroll Services 'indexPage' to check his/her details$")
	public void associate_is_on_the_Payroll_Services_indexPage_to_check_his_her_details() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		   driver=new ChromeDriver();
		   driver.get("http://localhost:4441");
		   viewAssociateDetailsPage=PageFactory.initElements(driver, ViewAssociateDetailsPage.class);
	}
	@When("^Associate clicks on 'View Associate Details' button$")
	public void associate_clicks_on_View_Associate_Details_button() throws Throwable {
		By getAssociateDetails=By.name("getAssociateDetails");
	    WebElement getAssociateDetailsTxt=driver.findElement(getAssociateDetails);
	    getAssociateDetailsTxt.click();
	}

	@When("^Associate enters valid associate Id$")
	public void associate_enters_valid_associate_Id() throws Throwable {
	    viewAssociateDetailsPage.setAssociateId("1");
	    viewAssociateDetailsPage.clickCheckAssociateDetails();
	}

	@Then("^Associate is directed to 'displayAssociateDetailsPage'$")
	public void associate_is_directed_to_displayAssociateDetailsPage() throws Throwable {
		String actualTitle=driver.getTitle();
	    String expectedTitle="Get Associate Details";
	    Assert.assertEquals(expectedTitle,actualTitle);
	    driver.close();
	}

}
