package com.cg.payroll.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.payroll.beans.Login;

public interface LoginDAO extends JpaRepository<Login, String>{

}
