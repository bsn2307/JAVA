package com.cg.payroll.services;
import java.util.ArrayList;
import com.cg.payroll.beans.*;
public interface PayrollServices {
	int calculateNetSalary(int associateId);
	Associate getAssociateDetails(int associateId);
	ArrayList<Associate>getAllAsociateDetails();
	Associate acceptAssociateDetails(Associate associate);
}