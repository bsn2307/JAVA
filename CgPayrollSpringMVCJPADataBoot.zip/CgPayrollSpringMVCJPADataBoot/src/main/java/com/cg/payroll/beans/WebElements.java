package com.cg.payroll.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class WebElements {
	@FindBy(how=How.NAME,name="associateId")
	private WebElement associateId;
	@FindBy(how=How.NAME,name="yearlyInvestmentUnder80c")
	private WebElement yearlyInvestmentUnder80c;
	@FindBy(how=How.NAME,name="firstName")
	private WebElement firstName;
	@FindBy(how=How.NAME,name="lastName")
	private WebElement lastName;
	@FindBy(how=How.NAME,name="department")
	private WebElement department;
	@FindBy(how=How.NAME,name="designation")
	private WebElement designation;
	@FindBy(how=How.NAME,name="pancard")
	private WebElement pancard;
	@FindBy(how=How.NAME,name="emailId")
	private WebElement emailId;
	@FindBy(how=How.NAME,name="bankDetails.accountNumber")
	private WebElement accountNumber;
	@FindBy(how=How.NAME,name="bankDetails.bankName")
	private WebElement bankName;
	@FindBy(how=How.NAME,name="bankDetails.ifscCode")
	private WebElement ifscCode;
	@FindBy(how=How.NAME,name="salary.basicSalary")
	private WebElement basicSalary;
	@FindBy(how=How.NAME,name="salary.epf")
	private WebElement epf;
	@FindBy(how=How.NAME,name="salary.companyPf")
	private WebElement companyPf;
	@FindBy(how=How.XPATH,xpath="/html/body/div/table/tbody/tr[14]/td/input")
	private WebElement registerButton;
	@FindBy(how=How.XPATH,xpath="/html/body/div/h3[2]/a")
	private WebElement register;
	@FindBy(how=How.XPATH,xpath="/html/body/div/form/table/tbody/tr[2]/td/input")
	private WebElement associateDetailsButton;
	@FindBy(how=How.XPATH,xpath="/html/body/div/form/h3/input")
	private WebElement allAssociateDetailsButton;
	public void clickAllAssociateDetails() {
		allAssociateDetailsButton.click();
	}
	public void clickRegister() {
		register.click();
	}
	public void clickAssociateDetails() {
		associateDetailsButton.click();
	}

	public void clickSignIn() {
		registerButton.click();
	}

	public String getAssociateId() {
		return associateId.getAttribute("value");
	}

	public void setAssociateId(String associateId) {
		this.associateId.sendKeys(associateId);;
	}

	public String getYearlyInvestmentUnder80c() {
		return yearlyInvestmentUnder80c.getAttribute("value");
	}

	public void setYearlyInvestmentUnder80c(String yearlyInvestmentUnder80c) {
		this.yearlyInvestmentUnder80c.sendKeys(yearlyInvestmentUnder80c);;
	}

	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);;
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);;
	}

	public String getDepartment() {
		return department.getAttribute("value");
	}

	public void setDepartment(String department) {
		this.department.sendKeys(department);
	}

	public String getDesignation() {
		return designation.getAttribute("value");
	}

	public void setDesignation(String designation) {
		this.designation.sendKeys(designation);;
	}

	public String getPancard() {
		return pancard.getAttribute("value");
	}

	public void setPancard(String pancard) {
		this.pancard.sendKeys(pancard);;
	}

	public String getEmailId() {
		return emailId.getAttribute("value");
	}

	public void setEmailId(String emailId) {
		this.emailId.sendKeys(emailId);;
	}

	public String getAccountNumber() {
		return accountNumber.getAttribute("value");
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber.sendKeys(accountNumber);;
	}

	public String getBankName() {
		return bankName.getAttribute("value");
	}

	public void setBankName(String bankName) {
		this.bankName.sendKeys(bankName);
	}

	public String getIfscCode() {
		return ifscCode.getAttribute("value");
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode.sendKeys(ifscCode);
	}


	public String getBasicSalary() {
		return basicSalary.getAttribute("value");
	}


	public void setBasicSalary(String basicSalary) {
		this.basicSalary.sendKeys(basicSalary);;
	}


	public String getEpf() {
		return epf.getAttribute("value");
	}


	public void setEpf(String epf) {
		this.epf.sendKeys(epf);;
	}


	public String getCompanyPf() {
		return companyPf.getAttribute("value");
	}


	public void setCompanyPf(String companyPf) {
		this.companyPf .sendKeys(companyPf);
	}
	
}
