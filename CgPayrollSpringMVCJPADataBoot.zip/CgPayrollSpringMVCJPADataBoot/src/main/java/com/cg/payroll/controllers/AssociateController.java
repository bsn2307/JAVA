package com.cg.payroll.controllers;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Login;
import com.cg.payroll.services.PayrollServices;
@Controller
@SessionAttributes("username")
public class AssociateController {
	@Autowired
	private PayrollServices payrollServices;
	@RequestMapping("/registerUser")
	public ModelAndView registerLogin(@Valid@ModelAttribute Login user, BindingResult bindingResult) {
		if(bindingResult.hasErrors())
			return new ModelAndView("loginPage");
		payrollServices.acceptLogin(user);
		return new ModelAndView("redirect:/");

	}
	@RequestMapping("/login")
	public ModelAndView getLogin(@RequestParam("username") String username,@RequestParam("password") String password,HttpServletRequest request) {

		Login user = new Login(username, password);
		if(payrollServices.findLogin(user)) {
			HttpSession session = request.getSession();
			session.setAttribute("username", user.getUsername());
		return new ModelAndView("redirect:/welcome");
		}
		return new ModelAndView("loginPage");
	}
	@RequestMapping("/registerAssociate")
	public ModelAndView registerAssociateAction(@Valid@ModelAttribute Associate associate, BindingResult bindingResult) {
		if(bindingResult.hasErrors())
			return new ModelAndView("registerPage");
		associate=payrollServices.acceptAssociateDetails(associate);
		return new ModelAndView("registrationSuccessPage","associate",associate);
	}
	@RequestMapping("/associateDetails")
	public ModelAndView getAssociateDetailsAction(@RequestParam int associateId) {
		Associate associate =payrollServices.getAssociateDetails(associateId);
		return new ModelAndView("displayAssociateDetailsPage","associate",associate);	
	} 
	@RequestMapping("/getAllAssociateDetails")
	public ModelAndView getAllAssociateDetailsAction() {
		ArrayList<Associate> associates =payrollServices.getAllAsociateDetails();
		return new ModelAndView("displayAllAssociateDetailsPage","associates",associates);	
	} 
}