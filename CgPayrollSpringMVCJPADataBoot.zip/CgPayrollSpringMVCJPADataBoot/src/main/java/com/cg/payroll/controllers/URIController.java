package com.cg.payroll.controllers;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Login;
@Controller
public class URIController {
	Associate associate;
	Login login;
	@RequestMapping("/")
	public String getIndexPage() {
		return "loginPage";
	}
	@RequestMapping("/welcome")
	public String getWelcomePage() {
		return "indexPage";
	}
	@RequestMapping("/register")
	public String getRegisterPage() {
		return "registerPage";
	}
	@RequestMapping("/getAssociateDetails")
	public String getAssociateDetailsPage() {
		return "getAssociateDetailsPage";
	}
	@RequestMapping("/registerLogin")
	public String getregisterLoginPage() {
		return "registerLoginPage";
	}
	@ModelAttribute("associate")
	public Associate getAssociate() {
		associate=new Associate();
		return associate;
	}
	@ModelAttribute("login")
	public Login getLogin() {
		login =new Login();
		return login;
	}
}