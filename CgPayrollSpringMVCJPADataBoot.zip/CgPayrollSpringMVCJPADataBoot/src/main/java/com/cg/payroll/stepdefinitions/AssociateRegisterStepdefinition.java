package com.cg.payroll.stepdefinitions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.payroll.beans.AssociateRegisterPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class AssociateRegisterStepdefinition {
	private WebDriver driver;
	private AssociateRegisterPage associateRegisterPage;
	@Given("^Associate is on the Payroll Services 'indexPage'$")
	public void associate_is_on_the_Payroll_Services_indexPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		   driver=new ChromeDriver();
		   driver.get("http://localhost:4441");
		   associateRegisterPage=PageFactory.initElements(driver, AssociateRegisterPage.class);
	}

	@When("^Associate clicks on 'Register' button$")
	public void associate_clicks_on_Register_button() throws Throwable {
	    By register=By.name("register");
	    WebElement registerTxt=driver.findElement(register);
	    registerTxt.click();
	}

	@When("^Associate enters valid details$")
	public void associate_enters_valid_details() throws Throwable {
	   associateRegisterPage.setFirstName("Suprathik");
	   associateRegisterPage.setLastName("Barigala");
	   associateRegisterPage.setDepartment("ECE");
	   associateRegisterPage.setDesignation("Analyst");
	   associateRegisterPage.setPanCard("5648sfs");
	   associateRegisterPage.setEmailId("sb@gmail.com");
	   associateRegisterPage.setYearlyInvestmentUnder80c("10000");
	   associateRegisterPage.setAccountNo("67863546");
	   associateRegisterPage.setBankName("ICICI");
	   associateRegisterPage.setBankCode("ICICI0007");
	   associateRegisterPage.setBasicSalary("40000");
	   associateRegisterPage.setEpf("2000");
	   associateRegisterPage.setCompanyPf("2000");
	   associateRegisterPage.clickRegister();
	}

	@Then("^Associate is directed to 'registerSuccessPage'$")
	public void associate_is_directed_to_registerSuccessPage() throws Throwable {
		String actualTitle=driver.getTitle();
	    String expectedTitle="Registration Successful";
	    Assert.assertEquals(expectedTitle,actualTitle);
	    driver.close();
	}
}
