package com.cg.payroll.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewAllAssociateDetailsStepdefinition {
	private WebDriver driver;
	@Given("^Admin is on the Index Page of 'PayrollServices' to check all associate details$")
	public void admin_is_on_the_Index_Page_of_PayrollServices_to_check_all_associate_details() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		   driver=new ChromeDriver();
		   driver.get("http://localhost:4441");
	}

	@When("^Admin clicks on 'View All Associate Details' button$")
	public void admin_clicks_on_View_All_Associate_Details_button() throws Throwable {
		By getAllAssociateDetails=By.name("getAllAssociateDetails");
	    WebElement getAllAssociateDetailsTxt=driver.findElement(getAllAssociateDetails);
	    getAllAssociateDetailsTxt.click();
	}

	@Then("^Admin is directed to 'viewAllAssociateDetailsPage'$")
	public void admin_is_directed_to_viewAllAssociateDetailsPage() throws Throwable {
		String actualTitle=driver.getTitle();
	    String expectedTitle="Get All Associate Details";
	    Assert.assertEquals(expectedTitle,actualTitle);
	    driver.close();
	}

}
